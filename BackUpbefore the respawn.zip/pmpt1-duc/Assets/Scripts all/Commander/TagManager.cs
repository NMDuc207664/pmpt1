using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tags{
    public const string Ground = "Ground";
    public const string Player = "Player";
    public const string Enemy = "Enemy";
    public const string Atk1 = "atk1";
    public const string Atk2 = "atk2";
    public const string Atk3 = "atk3";
}
